UARTlib/UART.d UARTlib/UART.o: ../UARTlib/UART.c
